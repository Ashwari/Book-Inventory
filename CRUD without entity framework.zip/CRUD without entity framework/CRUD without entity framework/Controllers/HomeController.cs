﻿using CRUD_without_entity_framework.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;

namespace CRUD_without_entity_framework.Controllers
{
    public class HomeController : Controller
    {
        public string connection = "Data Source=ASHWARI\\SQLEXPRESS;Initial Catalog=CRUD_DB;Integrated Security=True;TrustServerCertificate=True";
        private readonly IWebHostEnvironment _hostingEnvironment;
        private readonly ILogger<HomeController> _logger;

        public HomeController(IWebHostEnvironment hostingEnvironment)
        {
            _hostingEnvironment = hostingEnvironment;
        }

        [HttpGet]
        public IActionResult Index()
        {
            DataTable DT = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                string Query = "SELECT * FROM BOOKS";
                SqlDataAdapter SDA = new SqlDataAdapter(Query, con);
                SDA.Fill(DT);
            }

                return View(DT);
        }
		public IActionResult AddBook()
		{
			return View("Create");
		}

     

        [HttpGet]
        public IActionResult Create()
        {
            return View(new BookModel());
        }
        [HttpPost]
        public IActionResult Create(BookModel bookModel, IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
             
                string uploadsFolder = Path.Combine(_hostingEnvironment.WebRootPath, "Images");
                Console.WriteLine("Uploads folder path: " + uploadsFolder);
                string uniqueFileName = Guid.NewGuid().ToString() + "_" + file.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    file.CopyTo(fileStream);
                }
                bookModel.Book_Image = uniqueFileName;
            }

            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                string Query = "INSERT INTO BOOKS (Book_Title, Book_Author, Book_Price, Book_Image) VALUES (@Book_Title, @Book_Author, @Book_Price, @Book_Image)";
                SqlCommand CMD = new SqlCommand(Query, con);
                CMD.Parameters.AddWithValue("@Book_Title", bookModel.Book_Title);
                CMD.Parameters.AddWithValue("@Book_Author", bookModel.Book_Author);
                CMD.Parameters.AddWithValue("@Book_Price", bookModel.Book_Price);
                CMD.Parameters.AddWithValue("@Book_Image", bookModel.Book_Image);
                CMD.ExecuteNonQuery();
            }
            return RedirectToAction("Index");
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            BookModel bookModel = new BookModel();
            DataTable DT = new DataTable();
            using(SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                string Query = "SELECT * FROM BOOKS WHERE Book_ID = @Book_ID";
                SqlDataAdapter SDA = new SqlDataAdapter(Query, con);
                SDA.SelectCommand.Parameters.AddWithValue("@Book_ID", id);
                SDA.Fill(DT);
            }
            if(DT.Rows.Count == 1)
            {
                bookModel.Book_ID = Convert.ToInt32(DT.Rows[0][0].ToString());
                bookModel.Book_Title = DT.Rows[0][1].ToString();
                bookModel.Book_Author = DT.Rows[0][2].ToString();
                bookModel.Book_Price = Convert.ToInt32(DT.Rows[0][3].ToString());
                return View(bookModel);
            }
            else
            return RedirectToAction("Index");
        }
        [HttpPost]
        public IActionResult Edit(BookModel bookModel)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                string Query = "UPDATE BOOKS SET Book_Title = @Book_Title, Book_Author = @Book_Author, Book_Price = @Book_Price WHERE Book_ID = @Book_ID";
                SqlCommand CMD = new SqlCommand(Query, con);
                CMD.Parameters.AddWithValue("@Book_ID", bookModel.Book_ID);
                CMD.Parameters.AddWithValue("@Book_Title", bookModel.Book_Title);
                CMD.Parameters.AddWithValue("@Book_Author", bookModel.Book_Author);
                CMD.Parameters.AddWithValue("@Book_Price", bookModel.Book_Price);
                CMD.ExecuteNonQuery();
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            BookModel bookModel = new BookModel();
            DataTable DT = new DataTable();
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                string Query = "SELECT * FROM BOOKS WHERE Book_ID = @Book_ID";
                SqlDataAdapter SDA = new SqlDataAdapter(Query, con);
                SDA.SelectCommand.Parameters.AddWithValue("@Book_ID", id);
                SDA.Fill(DT);
            }
            if (DT.Rows.Count == 1)
            {
                bookModel.Book_ID = Convert.ToInt32(DT.Rows[0][0].ToString());
                bookModel.Book_Title = DT.Rows[0][1].ToString();
                bookModel.Book_Author = DT.Rows[0][2].ToString();
                bookModel.Book_Price = Convert.ToInt32(DT.Rows[0][3].ToString());
                bookModel.Book_Image = DT.Rows[0][4].ToString();
                return View(bookModel);
            }
            else
                return RedirectToAction("Index");
        }
        [HttpPost]
        public IActionResult Delete(int id,BookModel bookModel)
        {
            using (SqlConnection con = new SqlConnection(connection))
            {
                con.Open();
                string Query = "DELETE FROM BOOKS WHERE Book_ID = @Book_ID";
                SqlCommand CMD = new SqlCommand(Query, con);
                CMD.Parameters.AddWithValue("@Book_ID", id);
                CMD.ExecuteNonQuery();
            }
            return RedirectToAction("Index");
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}