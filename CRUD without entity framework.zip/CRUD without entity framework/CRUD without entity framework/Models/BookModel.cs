﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CRUD_without_entity_framework.Models
{
    public class BookModel
    {
        public int Book_ID { get; set; }
        [Required(ErrorMessage = "Enter Book Title")]
        [DisplayName("Book Title:")]
        public string Book_Title { get; set; }
        [Required(ErrorMessage = "Enter Book Author")]
        [DisplayName("Book Author:")]
        public string Book_Author { get; set; }
        [Required(ErrorMessage = "Enter Book Price")]
        [DisplayName("Book Price:")]
        public int? Book_Price { get; set; }
        [DisplayName("Book Image:")]
        public string Book_Image { get; set; }
       

    }
}
